<?php
if($this->session->userdata('clientid')){
redirect(base_url('index'));
}

?><!DOCTYPE html>
<html>
<head>
	<title>Client Login | Mytetrax</title>
</head>
<body>
<link href="<?php echo base_url(); ?>resoursefile/assets/bootstrap/css/bootstrap.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="shortcut icon" href="<?php echo base_url(); ?>resoursefile/assets/dist/img/ico/favicon.png" type="image/x-icon">
 <link rel="stylesheet" href="<?php echo base_url(); ?>resoursefile/assets/dist/css/style.css">

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="<?php echo base_url(); ?>resoursefile/js/jquery-simple-validator.min.js"></script>

<style type="text/css"> 
body {
            background: #f3f3f3 !important;
        }
        .card {
            border: 1px solid #28a745;
        }
        .card-login {
            margin-top: 130px;
            padding: 18px;
            max-width: 30rem;
        }

        .card-header {
            color: #fff;
            /*background: #ff0000;*/
            font-family: sans-serif;
            font-size: 20px;
            font-weight: 600 !important;
            margin-top: 10px;
            border-bottom: 0;
        }

        .input-group-prepend span{
            width: 50px;
            background-color: #262626;
            color: #fff;
            border:0 !important;
        }

        input:focus{
            outline: 0 0 0 0  !important;
            box-shadow: 0 0 0 0 !important;
        }

        .login_btn{
            width: 130px;
        }

        .login_btn:hover{
            color: #fff;
            background-color: #ff0000;
        }

        .btn-outline-danger {
            color: #fff;
            font-size: 18px;
            background-color: #28a745;
            background-image: none;
            border-color: #28a745;
        }

        .form-control {
            display: block;
            width: 100%;
            height: calc(2.25rem + 2px);
            padding: 0.375rem 0.75rem;
            font-size: 1.2rem;
            line-height: 1.6;
            color: #28a745;
            background-color: transparent;
            background-clip: padding-box;
            border: 1px solid #28a745;
            border-radius: 0;
            transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
        }

        .input-group-text {
            display: -ms-flexbox;
            display: flex;
            -ms-flex-align: center;
            align-items: center;
            padding: 0.375rem 0.75rem;
            margin-bottom: 0;
            font-size: 1.5rem;
            font-weight: 700;
            line-height: 1.6;
            color: #495057;
            text-align: center;
            white-space: nowrap;
            background-color: #e9ecef;
            border: 1px solid #ced4da;
            border-radius: 0;
        }</style>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css">
<div class="container">
    <div class="card card-login mx-auto text-center bg-dark">
        <div class="card-header mx-auto bg-dark">
            <span> <img src="<?php echo base_url(); ?>resoursefile/assets/dist/img/logo.png" class="w-75" alt="Logo"> </span><br/>
                        <span class="logo_title mt-5"> Client Login </span>

        </div>
        <div class="card-body">
            <form action="client_login" method="post" validate="true">
                <?php
                            echo $this->session->flashdata('cerror');
                           ?>
                            <?php
                             echo $this->session->flashdata('updatee');
                            echo $this->session->flashdata('client');
                             
                           ?>
                <div class="input-group form-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fas fa-user"></i></span>
                    </div>
                    <input type="text" name="clientid" class="form-control" required="" placeholder="Enter Client Id">
                </div>
                 <span class="text-danger"><?php echo form_error('clientid'); ?></span>
                <div class="input-group form-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fas fa-key"></i></span>
                    </div>
                    <input type="password" name="password" class="form-control" placeholder="Password" required="">
                </div>
                 <span class="text-danger"><?php echo form_error('password'); ?></span>

                <div class="form-group">
                    <input type="submit" name="btn" value="Login..." class="btn btn-outline-danger float-right login_btn">
                </div>

            </form>
<div class="input-group form-group">
                    <div class="input-group-prepend">
                            <a href="forgot_client" class="txt1">
                                Forgot Password?
                            </a>
                        </div>
                    </div>
        </div>

    </div>

</div>
</body>
</html>