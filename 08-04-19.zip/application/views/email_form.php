<!DOCTYPE html>
<html>

<body>
<h2>Email Successfully Delivered</h2>


<?php echo form_open('index.php/Email_controller/send_email'); ?>

<input type="email" name="email" required/>
<input type="submit" name="submit" value="Send Email" required/>

<?php echo form_close(); ?>
</body>

</html>