<?php
class mail_model extends CI_Model {
	
	 
	function mail_model() {
		parent::__construct();
		 
  	}
	
	 function sendActivationMailtoUser($userActiveKey,$first_name,$emailId,$password){
 		$mailTemplates = $this->getMailTemplates(4);
		$verifyUrl = mail_url().'home/verify/'.$userActiveKey; 
		$subject  = $mailTemplates['template_subject'];
		$phrase  = $mailTemplates['template_content'];
	 
		$search = array("{SITE_NAME}", "{SITE_PATH}","{USER_NAME}","{EMAIL}","{VERIFY_URL}","{PWD}");
		$replace   = array(site_name(),mail_url(),$first_name,$emailId,$verifyUrl,$password );
		$newphrase = str_replace($search, $replace, $phrase);
		
 		$config['mailtype'] = 'html';
		$config['charset'] = 'utf-8';
		$config['wordwrap'] = TRUE;
		$this->email->initialize($config);
		$this->email->clear(TRUE);
		$this->email->from(site_from_email(),site_name());
		$this->email->to($emailId);
		$this->email->subject($subject);
		$this->email->message($newphrase);
		$this->email->send();
		return true;
	} 
 
	 function sendVerificaionEmailToAdmin($first_name,$emailId,$userActiveKey){
 		$mailTemplates = $this->getMailTemplates(64);
		$verifyUrl = mail_url().'admin/verify/'.$userActiveKey; 
		$subject  = $mailTemplates['template_subject'];
		$phrase  = $mailTemplates['template_content'];
		$phrase = str_replace( base_url(), mail_url(), $phrase); 
		$search = array("{SITE_NAME}", "{SITE_PATH}","{USER_NAME}","{EMAIL}","{PWD}","{ADMIN_URL}","{USER_TYPE}","{VERIFY_URL}");
		$replace   = array(site_name(),mail_url(),$first_name,$emailId,$password,$verifyUrl,$userType,$verifyUrl );
		$newphrase = str_replace($search, $replace, $phrase);
 		$config['mailtype'] = 'html';
		$config['charset'] = 'utf-8';
		$config['wordwrap'] = TRUE;
		$this->email->initialize($config);
		$this->email->clear(TRUE);
		$this->email->from(site_from_email(),site_name());
		$this->email->to($emailId);
		$this->email->subject($subject);
		$this->email->message($newphrase);
		$this->email->send();
		return true;
		
	} 
	function adminForgotMail($userName,$userEmail,$userActiveKey){
		//echo $userEmail;
  		$mailTemplates = $this->getMailTemplates(3);
		$verifyUrl = mail_url().'admin/verify/'.$userActiveKey; 
		$subject  = $mailTemplates['template_subject'];
		$phrase  = $mailTemplates['template_content'];
		$phrase = str_replace( base_url(), mail_url(), $phrase); 
		$search = array("{SITE_NAME}", "{SITE_PATH}","{USER_NAME}","{EMAIL}","{PWD}","{ADMIN_URL}","{USER_TYPE}","{VERIFY_URL}");
		$replace   = array(site_name(),mail_url(),$userName,$emailId,$password,$verifyUrl,$userType,$verifyUrl );
		$newphrase = str_replace($search, $replace, $phrase);
		//
  		$config['mailtype'] = 'html';
		$config['charset'] = 'utf-8';
		$config['wordwrap'] = TRUE;
		$this->email->initialize($config);
		$this->email->clear(TRUE);
		$this->email->from(site_from_email(),site_name());
		$this->email->to($userEmail);
		$this->email->subject($subject);
		$this->email->message($newphrase);
		$this->email->send();
		return true;	
	} 
	function userForgotMail($userName,$userEmail,$userActiveKey){
		//echo $userEmail;
  		$mailTemplates = $this->getMailTemplates(5);
		$verifyUrl = mail_url().'change-password/'.$userActiveKey; 
		$subject  = $mailTemplates['template_subject'];
		$phrase  = $mailTemplates['template_content'];
		 
		$search = array("{SITE_NAME}", "{SITE_PATH}","{USER_NAME}","{EMAIL}","{PWD}","{ADMIN_URL}","{USER_TYPE}","{VERIFY_URL}");
		$replace   = array(site_name(),mail_url(),$userName,$emailId,$password,$verifyUrl,$userType,$verifyUrl );
		$newphrase = str_replace($search, $replace, $phrase);
	 
  		$config['mailtype'] = 'html';
		$config['charset'] = 'utf-8';
		$config['wordwrap'] = TRUE;
		$this->email->initialize($config);
		$this->email->clear(TRUE);
		$this->email->from(site_from_email(),site_name());
		$this->email->to($userEmail);
		$this->email->subject($subject);
		$this->email->message($newphrase);
		$this->email->send();
		return true;	
	}
	function sendNewQuestionMailToUser($userName,$userEmail){
  		$mailTemplates = $this->getMailTemplates(7);
		$subject  = $mailTemplates['template_subject'];
		$phrase  = $mailTemplates['template_content'];
 		$search = array("{SITE_NAME}", "{SITE_PATH}","{USER_NAME}");
		$replace   = array(site_name(),mail_url(),$userName);
		$newphrase = str_replace($search, $replace, $phrase);
		//
  		$config['mailtype'] = 'html';
		$config['charset'] = 'utf-8';
		$config['wordwrap'] = TRUE;
		$this->email->initialize($config);
		$this->email->clear(TRUE);
		$this->email->from(site_from_email(),site_name());
		$this->email->to($userEmail);
		$this->email->subject($subject);
		$this->email->message($newphrase);
		$this->email->send();
		return true;	
	} 
	
	function sendNewQuestionMailToSubs($MSG,$userEmail,$url,$sub_id){
		$notify_url = mail_url().'home/un_sub/'.base64_encode($sub_id);
  		$mailTemplates = $this->getMailTemplates(9);
		$subject  = $mailTemplates['template_subject'];
		$phrase  = $mailTemplates['template_content'];
 		$search = array("{SITE_NAME}", "{SITE_PATH}","{MSG}","{VERIFY_URL}","{UNSUBLINK}");
		$replace   = array(site_name(),mail_url(),$MSG,$url,$notify_url); 
		$newphrase = str_replace($search, $replace, $phrase);
		
		$searchS = array("{SITE_NAME}", "{SITE_PATH}","{MSG}");
		$replaceS   = array(site_name(),mail_url(),$MSG);
		$newphraseS = str_replace($search, $replace, $subject);
		 
  		$config['mailtype'] = 'html';
		$config['charset'] = 'utf-8';
		$config['wordwrap'] = TRUE;
		$this->email->initialize($config);
		$this->email->clear(TRUE);
		$this->email->from(site_from_email(),site_name());
		$this->email->to($userEmail);
		$this->email->subject($newphraseS);
		$this->email->message($newphrase);
		$this->email->send();
		return true;	
	} 
	
	function sendNewQuestionMailToAdmin($userName = false,$userEmail,$questionTitle){ 
		if(!$userName)$userName = 'Anonymous ';
  		$mailTemplates = $this->getMailTemplates(6);
		$subject  = $mailTemplates['template_subject'];
		$phrase  = $mailTemplates['template_content'];
 		$search = array("{SITE_NAME}", "{SITE_PATH}","{USER_NAME}","{QUESTION}");
		$replace   = array(site_name(),mail_url(),ucfirst($userName),$questionTitle);
		$newphrase = str_replace($search, $replace, $phrase);
	 
  		$config['mailtype'] = 'html';
		$config['charset'] = 'utf-8';
		$config['wordwrap'] = TRUE;
		$this->email->initialize($config);
		$this->email->clear(TRUE);
		$this->email->from(site_from_email(),site_name());
		$this->email->to(site_email());
		$this->email->subject($subject);
		$this->email->message($newphrase);
		$this->email->send();
		return true;	
	} 
	
	function sendNewVideoMailToAdmin($userName = false,$userEmail = false,$videoTitle){ 
		if(!$userName)$userName = 'Anonymous ';
  		$mailTemplates = $this->getMailTemplates(13);
		$subject  = $mailTemplates['template_subject'];
		$phrase  = $mailTemplates['template_content'];
 		$search = array("{SITE_NAME}", "{SITE_PATH}","{USER_NAME}","{TITLE}");
		$replace   = array(site_name(),mail_url(),ucfirst($userName),$videoTitle);
		$newphrase = str_replace($search, $replace, $phrase);
//		echo $newphrase;exit;
   		$config['mailtype'] = 'html';
		$config['charset'] = 'utf-8';
		$config['wordwrap'] = TRUE;
		$this->email->initialize($config);
		$this->email->clear(TRUE);
		$this->email->from(site_from_email(),site_name());
		$this->email->to(site_email());
		$this->email->subject($subject);
		$this->email->message($newphrase);
		$this->email->send();
		return true;	
	} 

	function sendNewAnswerMailToUser($answerQuestionId,$answerDetails){
  		$mailTemplates = $this->getMailTemplates(9);
		$cateogoryRow = $this->question_model->getQuestionRowById($answerQuestionId);	
		//print_r($cateogoryRow);exit;
		$subject  = $mailTemplates['template_subject'];
		$phrase  = $mailTemplates['template_content'];
 		$search = array("{SITE_NAME}", "{SITE_PATH}","{USER_NAME}","{QUESTION}","{ANSWER}");
		$replace   = array(site_name(),mail_url(),$cateogoryRow->accountUsername,$cateogoryRow->questionTitle,$answerDetails);
		$newphrase = str_replace($search, $replace, $phrase);
		//
  		$config['mailtype'] = 'html';
		$config['charset'] = 'utf-8';
		$config['wordwrap'] = TRUE;
		$this->email->initialize($config);
		$this->email->clear(TRUE);
		$this->email->from(site_from_email(),site_name());
		$this->email->to($cateogoryRow->accountEmail);
		$this->email->subject($subject);
		$this->email->message($newphrase);
		$this->email->send();
		return true;	
	}  
	function sendNewAnswerMailToAdmin($userName,$userEmail,$answerQuestionId,$answerDetail){ 
  		$mailTemplates = $this->getMailTemplates(8);
		$cateogoryRow = $this->question_model->getQuestionRowById($answerQuestionId);	
		$subject  = $mailTemplates['template_subject'];
		$phrase  = $mailTemplates['template_content'];
 		$search = array("{SITE_NAME}", "{SITE_PATH}","{USER_NAME}","{QUESTION}","{ANSWER}");
		$replace   = array(site_name(),mail_url(),ucfirst($userName),$cateogoryRow->questionTitle,$answerDetail);
		$newphrase = str_replace($search, $replace, $phrase);
	// 
  		$config['mailtype'] = 'html';
		$config['charset'] = 'utf-8';
		$config['wordwrap'] = TRUE;
		$this->email->initialize($config);
		$this->email->clear(TRUE);
		$this->email->from(site_from_email(),site_name());
		$this->email->to(site_email());
		$this->email->subject($subject);
		$this->email->message($newphrase);
		$this->email->send();
		return true;	
	} 
	function sendNewCommentMailToAdmin($commentName,$userEmail,$commentDetails){ 
  		$mailTemplates = $this->getMailTemplates(10);
 		$subject  = $mailTemplates['template_subject'];
		$phrase  = $mailTemplates['template_content'];
 		$search = array("{SITE_NAME}", "{SITE_PATH}","{NAME}","{EMAIL}","{COMMENTS}");
		$replace   = array(site_name(),mail_url(),ucfirst($commentName),$userEmail,$commentDetails);
		$newphrase = str_replace($search, $replace, $phrase);
   		$config['mailtype'] = 'html';
		$config['charset'] = 'utf-8';
		$config['wordwrap'] = TRUE;
		$this->email->initialize($config);
		$this->email->clear(TRUE);
		$this->email->from(site_from_email(),site_name());
		$this->email->to(site_email());
		$this->email->subject($subject);
		$this->email->message($newphrase);
		$this->email->send();
		return true;	
	} 
	function sendSubMail($userEmail){ 
  		$mailTemplates = $this->getMailTemplates(8);
 		$subject  = $mailTemplates['template_subject'];
		$phrase  = $mailTemplates['template_content'];
 		$search = array("{SITE_NAME}", "{SITE_PATH}","{NAME}","{EMAIL}");
		$replace   = array(site_name(),mail_url(),ucfirst($commentName),$userEmail);
		$newphrase = str_replace($search, $replace, $phrase);
		 
   		$config['mailtype'] = 'html';
		$config['charset'] = 'utf-8';
		$config['wordwrap'] = TRUE;
		$this->email->initialize($config);
		$this->email->clear(TRUE);
		$this->email->from(site_from_email(),site_name());
		$this->email->to(site_email());
		$this->email->subject($subject);
		$this->email->message($newphrase);
		$this->email->send();
		return true;	
	} 
	
	function sendBabyNameMailToAdmin($babyName,$babyNameMeaning,$babyNameGender){ 
  		$mailTemplates = $this->getMailTemplates(11);
 		$subject  = $mailTemplates['template_subject'];
		$phrase  = $mailTemplates['template_content'];
 		$search = array("{SITE_NAME}", "{SITE_PATH}","{NAME}","{MEAN}","{GENDER}");
		$replace   = array(site_name(),mail_url(),ucfirst($babyName),$babyNameMeaning,$babyNameGender);
		$newphrase = str_replace($search, $replace, $phrase);
		//echo $newphrase;exit;
   		$config['mailtype'] = 'html';
		$config['charset'] = 'utf-8';
		$config['wordwrap'] = TRUE;
		$this->email->initialize($config);
		$this->email->clear(TRUE);
		$this->email->from(site_from_email(),site_name());
		$this->email->to(site_email());
		$this->email->subject($subject);
		$this->email->message($newphrase);
		//$this->email->send();
		return true;	
	} 
 	function getMailTemplates($tempId = false){
		$this->db->where('template_id',$tempId);
		$mailQuery = $this->db->get('email_templates');
 		if($mailQuery->num_rows()){return $mailQuery->row_array();}
		else return false;
		
	} 
	

}



