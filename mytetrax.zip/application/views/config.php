<?php
 
// Firebase API Key
define('FIREBASE_API_KEY', 'AAAAeuaoyCI:APA91bGKQ-0hUVd2LDwOdiANquqn03sAI3DKnbLq0bcM-j69hnhDnQMtG9i_Oet34vkgsrXja9L6ggcsKA5yhkqOFGKm9SiXHudEYl0f1LgqTB3ejLWObnaoqwumeu8fvEmuzixhZS5-');

?>